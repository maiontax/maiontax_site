export type IconType = {
  fill?: string;
};
