export const BASE_URL = process.env.baseUrl;

export const COLOR_PRIMARY = "#1b2943";
export const COLOR_SECONDARY = "#c4a162";
